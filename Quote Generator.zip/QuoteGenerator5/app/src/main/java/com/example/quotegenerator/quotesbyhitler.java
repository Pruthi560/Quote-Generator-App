package com.example.quotegenerator;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quotegenerator.Adapter.QuoteAdapter;
import com.example.quotegenerator.Model.Quotesmodel;

import java.util.ArrayList;
import java.util.List;

public class quotesbyhitler extends AppCompatActivity {

    RecyclerView recyclerView;
    List<Quotesmodel> list;
    QuoteAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_quotesbyhitler);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        recyclerView=findViewById(R.id.recycleview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list=new ArrayList<>();
        recyclerView.setHasFixedSize(true);
        Quotesmodel list1=new Quotesmodel("“Do not compare yourself to others. If you do so, you are insulting yourself.”\n" +
                "― Adolf Hitler");

        Quotesmodel list2=new Quotesmodel("“if you want to shine like sun first you have to burn like it.”\n" +
                "― Adolf Hitler");

        Quotesmodel list3=new Quotesmodel("“Anyone can deal with victory. Only the mighty can bear defeat.”\n" +
                "― Adolf Hitler");

        Quotesmodel list4=new Quotesmodel("“The man who has no sense of history, is like a man who has no ears or eyes”\n" +
                "― Adolf Hitler");

        Quotesmodel list5=new Quotesmodel("“When diplomacy ends, War begins.”\n" +
                "― Adolf Hitler");

        Quotesmodel list6=new Quotesmodel("“Reading is not an end to itself, but a means to an end.”\n" +
                "― Adolf Hitler");

        Quotesmodel list7=new Quotesmodel("“If you win, you need not have to explain...If you lose, you should not be there to explain!”\n" +
                "― Adolf Hitler");


        list.add(list1);
        list.add(list2);
        list.add(list3);
        list.add(list4);
        list.add(list5);
        list.add(list6);
        list.add(list7);
        adapter=new QuoteAdapter(getApplicationContext(),list);
        recyclerView.setAdapter(adapter);
    }
}