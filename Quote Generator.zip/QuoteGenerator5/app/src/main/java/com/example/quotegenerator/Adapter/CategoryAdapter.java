package com.example.quotegenerator.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quotegenerator.MainActivity;
import com.example.quotegenerator.Model.CategoryModel;
import com.example.quotegenerator.R;
import com.example.quotegenerator.quotesbyabdul;
import com.example.quotegenerator.quotesbyalbert;
import com.example.quotegenerator.quotesbyambedkar;
import com.example.quotegenerator.quotesbychanakya;
import com.example.quotegenerator.quotesbyhitler;
import com.example.quotegenerator.quotesbyravinder;
import com.example.quotegenerator.quotesbystephen;
import com.example.quotegenerator.quotesbyswami;

import java.util.List;

public class CategoryAdapter  extends RecyclerView.Adapter<CategoryAdapter.CategoryHolder> {
    Context context;
    List<CategoryModel> list;

    public CategoryAdapter(Context context, List<CategoryModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public CategoryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CategoryHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.category_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryHolder holder, int position) {
        holder.imageView.setImageResource(list.get(position).getImage());
        holder.textView.setText(list.get(position).getName());
        holder.textView.setOnClickListener(v -> {
//            Toast.makeText(context, ""+list.get(position).getName(),Toast.LENGTH_SHORT).show();
            switch (list.get(position).getName()) {
                case "Quotes By Hitler": {
                    Intent intent = new Intent(context, quotesbyhitler.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
                case "Quotes By APJ Abdul Kalam": {
                    Intent intent = new Intent(context, quotesbyabdul.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
                case "Quotes By Chanakya": {
                    Intent intent = new Intent(context, quotesbychanakya.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
                case "Quotes By Albert Einstein": {
                    Intent intent = new Intent(context, quotesbyalbert.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
                case "Quotes By Dr.B.R. Ambedkar": {
                    Intent intent = new Intent(context, quotesbyambedkar.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
                case "Quotes By Stephen Hawkins": {
                    Intent intent = new Intent(context, quotesbystephen.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
                case "Quotes By Swami Vivekanand": {
                    Intent intent = new Intent(context, quotesbyswami.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
                case "Quotes By Rabindranath Tagore": {
                    Intent intent = new Intent(context, quotesbyravinder.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
            }
        });
    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    class CategoryHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textView;

        public CategoryHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.category_image);
            textView = itemView.findViewById(R.id.category_name);
        }
    }
}
