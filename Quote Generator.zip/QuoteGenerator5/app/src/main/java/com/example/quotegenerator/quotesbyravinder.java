package com.example.quotegenerator;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quotegenerator.Adapter.QuoteAdapter;
import com.example.quotegenerator.Model.Quotesmodel;

import java.util.ArrayList;
import java.util.List;

public class quotesbyravinder extends AppCompatActivity {

    RecyclerView recyclerView;
    List<Quotesmodel> list;
    QuoteAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_quotesbyravinder);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        recyclerView=findViewById(R.id.recycleview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list=new ArrayList<>();
        recyclerView.setHasFixedSize(true);
        Quotesmodel list1=new Quotesmodel("“Clouds come floating into my life, no longer to carry rain or usher storm, but to add color to my sunset sky.”\n" +
                "― Rabindranath Tagore");

        Quotesmodel list2=new Quotesmodel("“If you cry because the sun has gone out of your life, your tears will prevent you from seeing the stars.”\n" +
                "― Rabindranath Tagore");

        Quotesmodel list3=new Quotesmodel("“It is very simple to be happy, but it is very difficult to be simple.”\n" +
                "― Rabindranath Tagore");

        Quotesmodel list4=new Quotesmodel("“You can’t cross the sea merely by standing and staring at the water.”\n" +
                "― Rabindranath Tagore");

        Quotesmodel list5=new Quotesmodel("“Faith is the bird that feels the light and sings when the dawn is still dark.”\n" +
                "― Rabindranath Tagore");

        Quotesmodel list6=new Quotesmodel("“The small wisdom is like water in a glass:\n" +
                "clear, transparent, pure.\n" +
                "The great wisdom is like the water in the sea:\n" +
                "dark, mysterious, impenetrable.”\n" +
                "― Rabindranath Tagore");

        Quotesmodel list7=new Quotesmodel("“Reach high, for stars lie hidden in you. Dream deep, for every dream precedes the goal.”\n" +
                "― Rabindranath Tagore");


        list.add(list1);
        list.add(list2);
        list.add(list3);
        list.add(list4);
        list.add(list5);
        list.add(list6);
        list.add(list7);
        adapter=new QuoteAdapter(getApplicationContext(),list);
        recyclerView.setAdapter(adapter);
    }
}