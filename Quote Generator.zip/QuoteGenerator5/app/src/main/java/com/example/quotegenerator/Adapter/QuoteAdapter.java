package com.example.quotegenerator.Adapter;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quotegenerator.Model.Quotesmodel;
import com.example.quotegenerator.R;

import java.util.List;

public class QuoteAdapter extends RecyclerView.Adapter<QuoteAdapter.QuoteHolder>{
    Context context;
    List<Quotesmodel> quotesmodelList;
    public QuoteAdapter(Context context, List<Quotesmodel> quoteModelList){
        this.context = context;
        this.quotesmodelList = quoteModelList;
    }
    @NonNull
    @Override
    public QuoteHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new QuoteHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.quote_item,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull QuoteHolder holder, int position) {
        holder.textView.setText(quotesmodelList.get(position).getQuotes1() );
        holder.copy.setOnClickListener(v -> {
            ClipboardManager clipboardManager=(ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip=ClipData.newPlainText("label",quotesmodelList.get(position).getQuotes1());
            assert clipboardManager!=null;
            clipboardManager.setPrimaryClip(clip);
            Toast.makeText(context,"Quote copied",Toast.LENGTH_SHORT).show();
        });



    }

    @Override
    public int getItemCount() {
        return  quotesmodelList.size();
    }

    class QuoteHolder extends RecyclerView.ViewHolder{
        TextView textView;
        ConstraintLayout copy;
        RelativeLayout quoteRl;

        public QuoteHolder(@NonNull View itemView) {
            super(itemView);
            textView=itemView.findViewById(R.id.quote);
            copy=itemView.findViewById(R.id.copy);


        }
    }
}
