package com.example.quotegenerator;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quotegenerator.Adapter.QuoteAdapter;
import com.example.quotegenerator.Model.Quotesmodel;

import java.util.ArrayList;
import java.util.List;

public class quotesbyambedkar extends AppCompatActivity {

    RecyclerView recyclerView;
    List<Quotesmodel> list;
    QuoteAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_quotesbyambedkar);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        recyclerView=findViewById(R.id.recycleview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list=new ArrayList<>();
        recyclerView.setHasFixedSize(true);
        Quotesmodel list1=new Quotesmodel("“Cultivation of mind should be the ultimate aim of human existence.”\n" +
                "― Bhimrao Ramji Ambedkar");

        Quotesmodel list2=new Quotesmodel("“If I find the constitution being misused, I shall be the first to burn it.”\n" +
                "― Bhimrao Ramji Ambedkar");
        Quotesmodel list3=new Quotesmodel("“Life should be great rather than long.”\n" +
                "― Bhimrao Ramji Ambedkar");

        Quotesmodel list4=new Quotesmodel("“Indifferentism is the worst kind of disease that can affect people.”\n" +
                "― Bhimrao Ramji Ambedkar");

        Quotesmodel list5=new Quotesmodel("“The relationship between husband and wife should be one of closest friends.”\n" +
                "― Bhim Rao Ambedkar");

        Quotesmodel list6=new Quotesmodel("“I measure the progress of a community by the degree of progress which women have achieved.”\n" +
                "― Bhim Rao Ambedkar");

        Quotesmodel list7=new Quotesmodel("“Humans are mortal. So are ideas. An idea needs propagation as much as a plant needs watering. Otherwise both will wither and die.”\n" +
                "― Bhim Rao Ambedkar");


        list.add(list1);
        list.add(list2);
        list.add(list3);
        list.add(list4);
        list.add(list5);
        list.add(list6);
        list.add(list7);
        adapter=new QuoteAdapter(getApplicationContext(),list);
        recyclerView.setAdapter(adapter);
    }

}