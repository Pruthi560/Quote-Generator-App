package com.example.quotegenerator;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quotegenerator.Adapter.QuoteAdapter;
import com.example.quotegenerator.Model.Quotesmodel;

import java.util.ArrayList;
import java.util.List;

public class quotesbyswami extends AppCompatActivity {

    RecyclerView recyclerView;
    List<Quotesmodel> list;
    QuoteAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_quotesbyswami);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        recyclerView=findViewById(R.id.recycleview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list=new ArrayList<>();
        recyclerView.setHasFixedSize(true);
        Quotesmodel list1=new Quotesmodel("“You have to grow from the inside out. None can teach you,\n" +
                "none can make you spiritual.\n" +
                "There is no other teacher but your own soul.”\n" +
                "― Vivekananda");

        Quotesmodel list2=new Quotesmodel("“In a conflict between the heart and the brain, follow your heart.”\n" +
                "― Vivekananda");

        Quotesmodel list3=new Quotesmodel("“In a day, when you don't come across any problems - you can be sure that you are travelling in a wrong path”\n" +
                "― Vivekananda");

        Quotesmodel list4=new Quotesmodel("“The greatest religion is to be true to your own nature. Have faith in yourselves.”\n" +
                "― Vivekananda");

        Quotesmodel list5=new Quotesmodel("“The greatest sin is to think yourself weak”\n" +
                "― Vivekananda");

        Quotesmodel list6=new Quotesmodel("“Anything that makes weak - physically, intellectually and spiritually, reject it as poison.”\n" +
                "― Vivekananda");

        Quotesmodel list7=new Quotesmodel("“Dare to be free, dare to go as far as your thought leads, and dare to carry that out in your life.”\n" +
                "― Vivekananda");


        list.add(list1);
        list.add(list2);
        list.add(list3);
        list.add(list4);
        list.add(list5);
        list.add(list6);
        list.add(list7);
        adapter=new QuoteAdapter(getApplicationContext(),list);
        recyclerView.setAdapter(adapter);
    }
}