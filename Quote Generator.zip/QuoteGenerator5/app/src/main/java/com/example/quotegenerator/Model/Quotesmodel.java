package com.example.quotegenerator.Model;


public class Quotesmodel {
    String quote;
    public Quotesmodel(){
    }

    public Quotesmodel(String quote){
        this.quote = quote;
    }
    public String getQuotes1(){
        return quote;
    }
    public void setQuotes1(String quote){
        this.quote = quote;
    }

}
