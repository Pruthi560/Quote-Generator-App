package com.example.quotegenerator;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quotegenerator.Adapter.QuoteAdapter;
import com.example.quotegenerator.Model.Quotesmodel;

import java.util.ArrayList;
import java.util.List;

public class quotesbyalbert extends AppCompatActivity {
    RecyclerView recyclerView;
    List<Quotesmodel> list;
    QuoteAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_quotesbyalbert);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        recyclerView=findViewById(R.id.recycleview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list=new ArrayList<>();
        recyclerView.setHasFixedSize(true);
        Quotesmodel list1=new Quotesmodel("“Two things are infinite: \n " + "the universe and human stupidity; \n" + " and I'm not sure about the universe.”\n" +
                "― Albert Einstein");

        Quotesmodel list2=new Quotesmodel("“If you can't explain it to a six year old, \n " + "you don't understand it yourself.”\n" +
                "― Albert Einstein");

        Quotesmodel list3=new Quotesmodel("“Logic will get you from A to Z;\n"+" imagination will get you everywhere.”\n" +
                "― Albert Einstein");

        Quotesmodel list4=new Quotesmodel("“Life is like riding a bicycle. To keep your balance, you must keep moving.”\n" +
                "― Albert Einstein");

        Quotesmodel list5=new Quotesmodel("“Never memorize something that you can look up.”\n" +
                "― Albert Einstein");

        Quotesmodel list6=new Quotesmodel("“A clever person solves a problem.\n"+" A wise person avoids it.”\n" +
                "― Albert Einstein");

        Quotesmodel list7=new Quotesmodel("“Science without religion is lame, religion without science is blind.”\n" +
                "― Albert Einstein");


        list.add(list1);
        list.add(list2);
        list.add(list3);
        list.add(list4);
        list.add(list5);
        list.add(list6);
        list.add(list7);
        adapter=new QuoteAdapter(getApplicationContext(),list);
        recyclerView.setAdapter(adapter);
    }
}