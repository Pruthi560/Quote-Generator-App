package com.example.quotegenerator;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quotegenerator.Adapter.QuoteAdapter;
import com.example.quotegenerator.Model.Quotesmodel;

import java.util.ArrayList;
import java.util.List;

public class quotesbyabdul extends AppCompatActivity {
    RecyclerView recyclerView;
    List<Quotesmodel> list;
    QuoteAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quotesbyabdul);
        recyclerView=findViewById(R.id.recycleview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list=new ArrayList<>();
        recyclerView.setHasFixedSize(true);
        Quotesmodel list1=new Quotesmodel("“Dream is not that which you see while sleeping \n" + "it is something that does not let you sleep.”\n" +
                "― A.P.J. Abdul Kalam");

        Quotesmodel list2=new Quotesmodel("“Dream, Dream Dream\n" +
                "Dreams transform into thoughts\n" +
                "And thoughts result in action.”\n" +
                "― A.P.J ABDUL KALAM");

        Quotesmodel list3=new Quotesmodel("“It Is Very Easy To Defeat Someone,\n" + " But It Is Very Hard To Win Someone”\n" +
                "― A.P.J Abdul Kalam ");

        Quotesmodel list4=new Quotesmodel("“All Birds find shelter during a rain.\n" +
                "But Eagle avoids rain by flying above\n" +
                "the Clouds.\n" +
                "\n" +
                "Problems are common, but attitude\n" +
                "makes the difference!!!”\n" +
                "― A.P.J Abdul Kalam");

        Quotesmodel list5=new Quotesmodel("“Dream is not the thing you see in sleep but is that thing that doesn't let you sleep.”\n" +
                "― A.P.J. Abdul Kalam");

        Quotesmodel list6=new Quotesmodel("“Learning gives creativity\n" +
                "Creativity leads to thinking\n" +
                "Thinking provides knowledge\n" +
                "Knowledge makes you great.”\n" +
                "― A.P.J. Abdul Kalam");

        Quotesmodel list7=new Quotesmodel("“Failure will never overtake me\n " + "if my definition to succeed is strong enough”\n" +
                "― A.P.J Abdul Kalam");


        list.add(list1);
        list.add(list2);
        list.add(list3);
        list.add(list4);
        list.add(list5);
        list.add(list6);
        list.add(list7);
        adapter=new QuoteAdapter(getApplicationContext(),list);
        recyclerView.setAdapter(adapter);
    }
}