package com.example.quotegenerator;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quotegenerator.Adapter.QuoteAdapter;
import com.example.quotegenerator.Model.Quotesmodel;

import java.util.ArrayList;
import java.util.List;

public class quotesbystephen extends AppCompatActivity {

    RecyclerView recyclerView;
    List<Quotesmodel> list;
    QuoteAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_quotesbystephen);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        recyclerView=findViewById(R.id.recycleview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list=new ArrayList<>();
        recyclerView.setHasFixedSize(true);
        Quotesmodel list1=new Quotesmodel("“Quiet people have the loudest minds.”\n" +
                "― Stephen Hawking");

        Quotesmodel list2=new Quotesmodel("“Life would be tragic if it weren't funny.”\n" +
                "― Stephen Hawking\n");

        Quotesmodel list3=new Quotesmodel("“Intelligence is the ability to adapt to change. ”\n" +
                "― Stephen Hawking");

        Quotesmodel list4=new Quotesmodel("“[In the Universe it may be that] Primitive life is very common and intelligent life is fairly rare. Some would say it has yet to occur on Earth.”\n" +
                "― Stephen W. Hawking");

        Quotesmodel list5=new Quotesmodel("“The universe doesn't allow perfection.”\n" +
                "― Stephen Hawking");

        Quotesmodel list6=new Quotesmodel("“My goal is simple. It is a complete understanding of the universe, why it is as it is and why it exists at all.”\n" +
                "― Stephen Hawking");

        Quotesmodel list7=new Quotesmodel("“We are just an advanced breed of monkeys on a minor planet of a very average star. But we can understand the Universe. That makes us something very special.”\n" +
                "― Stephen Hawking");


        list.add(list1);
        list.add(list2);
        list.add(list3);
        list.add(list4);
        list.add(list5);
        list.add(list6);
        list.add(list7);
        adapter=new QuoteAdapter(getApplicationContext(),list);
        recyclerView.setAdapter(adapter);
    }
}