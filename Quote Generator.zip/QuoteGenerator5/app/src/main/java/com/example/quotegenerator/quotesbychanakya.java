package com.example.quotegenerator;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quotegenerator.Adapter.QuoteAdapter;
import com.example.quotegenerator.Model.Quotesmodel;

import java.util.ArrayList;
import java.util.List;

public class quotesbychanakya extends AppCompatActivity {

    RecyclerView recyclerView;
    List<Quotesmodel> list;
    QuoteAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_quotesbychanakya);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        recyclerView=findViewById(R.id.recycleview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list=new ArrayList<>();
        recyclerView.setHasFixedSize(true);
        Quotesmodel list1=new Quotesmodel("“As soon as the fear approaches near, attack and destroy it.”\n" +
                "― Chanakya");

        Quotesmodel list2=new Quotesmodel("“A person should not be too honest. Straight trees are cut first and honest people are screwed first.”\n" +
                "― Chanakya");

        Quotesmodel list3=new Quotesmodel("“Books are as useful to a stupid person as a mirror is useful to a blind person.”\n" +
                "― Chanakya");

        Quotesmodel list4=new Quotesmodel("“Every neighbouring state is an enemy and the enemy’s enemy is a friend.”\n" +
                "― Kautilya");

        Quotesmodel list5=new Quotesmodel("“There is no enemy like infatuation and fire like wrath.”\n" +
                "― Chanakya");

        Quotesmodel list6=new Quotesmodel("“Education is the best friend. An educated person is respected everywhere.”\n" +
                "― Chanakya");

        Quotesmodel list7=new Quotesmodel("“Either Scholarship or Death will be my refuge.\n" +
                "पाण्डित्यं शरणं वा मे मृत्युर्वा॥”\n" +
                "― Chanakya");


        list.add(list1);
        list.add(list2);
        list.add(list3);
        list.add(list4);
        list.add(list5);
        list.add(list6);
        list.add(list7);
        adapter=new QuoteAdapter(getApplicationContext(),list);
        recyclerView.setAdapter(adapter);
    }
}