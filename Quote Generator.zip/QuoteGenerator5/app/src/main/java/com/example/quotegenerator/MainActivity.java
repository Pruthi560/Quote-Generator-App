package com.example.quotegenerator;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quotegenerator.Adapter.CategoryAdapter;
import com.example.quotegenerator.Model.CategoryModel;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    CategoryAdapter adapter;
    List<CategoryModel> list;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



                recyclerView=findViewById(R.id.recycleview);
                recyclerView.setLayoutManager(new GridLayoutManager(this,2));
                list=new ArrayList<>();
                recyclerView.setHasFixedSize(true);
                CategoryModel list1=new CategoryModel("Quotes By APJ Abdul Kalam",R.drawable.abdul);
                CategoryModel list2=new CategoryModel("Quotes By Albert Einstein",R.drawable.albert);
                CategoryModel list3=new CategoryModel("Quotes By Dr.B.R. Ambedkar",R.drawable.ambedkar);
                CategoryModel list4=new CategoryModel("Quotes By Chanakya",R.drawable.chanakya2);
                CategoryModel list5=new CategoryModel("Quotes By Hitler",R.drawable.hitler);
                CategoryModel list6=new CategoryModel("Quotes By Rabindranath Tagore",R.drawable.ravinder);
                CategoryModel list7=new CategoryModel("Quotes By Stephen Hawkins",R.drawable.stephen);
                CategoryModel list8=new CategoryModel("Quotes By Swami Vivekanand",R.drawable.swami);

                list.add(list1);
                list.add(list2);
                list.add(list3);
                list.add(list4);
                list.add(list5);
                list.add(list6);
                list.add(list7);
                list.add(list8);

                adapter=new CategoryAdapter(this,list);
                recyclerView.setAdapter(adapter);
            }
        }

